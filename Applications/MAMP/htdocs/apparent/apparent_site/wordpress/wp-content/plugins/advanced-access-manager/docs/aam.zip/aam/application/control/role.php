<?php

/**
 * ======================================================================
 * LICENSE: This file is subject to the terms and conditions defined in *
 * file 'license.txt', which is part of this source code package.       *
 * ======================================================================
 */
class aam_Control_Role extends aam_Control_Subject {

    /**
     * Subject UID: ROLE
     */
    const UID = 'role';

    /**
     * Retrieve Role based on ID
     * 
     * @return WP_Role|null
     * 
     * @access protected
     */
    protected function retrieveSubject() {
        $roles = new WP_Roles;
        $role = $roles->get_role($this->getId());

        if (is_null($role)) {
            aam_Core_Console::write('Role ' . $this->getId() . ' does not exist');
        }

        return $role;
    }

    /**
     * Retrieve access objects for role
     * 
     * @return array
     * 
     * @access public
     */
    protected function retrieveObjects() {
        //set default objects
        $objects = array(
            aam_Control_Menu::UID => new aam_Control_Menu($this),
            aam_Control_Metabox::UID => new aam_Control_Metabox($this),
            aam_Control_Post::UID => new aam_Control_Post($this),
            aam_Control_Term::UID => new aam_Control_Term($this),
            aam_Control_Capability::UID => new aam_Control_Capability($this)
        );

        return apply_filters('aam_access_objects', $objects, $this);
    }

    public function hasCapability($capability) {
        return $this->getSubject()->has_cap($capability);
    }

    public function updateCapability($capability, $grant) {
        return $this->getSubject()->add_cap($capability, $grant);
    }

    public function getCapabilities() {
        return $this->getSubject()->capabilities;
    }

    public function save(array $params) {
        foreach ($this->getObjects() as $object) {
            $object->save($params);
        }
    }

    public function updateOption($value, $object, $object_id = '') {
        return aam_Core_API::updateBlogOption(
                        $this->getOptionName($object, $object_id), $value
        );
    }

    public function readOption($object, $object_id = '') {
        return aam_Core_API::getBlogOption(
                        $this->getOptionName($object, $object_id)
        );
    }

    public function deleteOption($object, $object_id = '') {
        return aam_Core_API::deleteBlogOption(
                        $this->getOptionName($object, $object_id)
        );
    }

    protected function getOptionName($object, $object_id) {
        $name = "aam_{$object}" . ($object_id ? "_{$object_id}_" : '_');
        $name .= self::UID . '_' . $this->getId();

        return $name;
    }

}
