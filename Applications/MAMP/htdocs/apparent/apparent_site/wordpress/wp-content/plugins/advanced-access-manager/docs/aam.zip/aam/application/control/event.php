<?php

class aam_Control_Event extends aam_Control_Object {

    const UID = 'event';

    private $_option = array();

    public function save(array $params) {
        $events = (isset($params[self::UID]) ? $params[self::UID] : array());

        if (is_array($events)) {
            $this->getSubject()->updateOption($events, self::UID);
        }
    }

    public function init($object_id = '') {
        if ($this->getObjectId() !== $object_id) {
            $events = $this->getSubject()->readOption(self::UID);
            if (!is_array($events)) {
                $events = array();
            }

            $this->setOption($events);
        }
    }

    public function setOption(array $option) {
        $this->_option = $option;
    }

    public function getOption() {
        return $this->_option;
    }

}
