<?php

/**
 * ======================================================================
 * LICENSE: This file is subject to the terms and conditions defined in *
 * file 'license.txt', which is part of this source code package.       *
 * ======================================================================
 */
abstract class aam_View_Abstract {

    static private $_subject = null;

    public function __construct() {
        if (is_null(self::$_subject)) {
            $blog_id = intval(aam_Core_Request::request('blog', 1));
            $role_id = trim(aam_Core_Request::request('role'));
            $user_id = intval(aam_Core_Request::request('user'), 0);

            //initialize access config
            if ($user_id) {
                $this->setSubject(new aam_Control_User($user_id, $blog_id));
            } else {
                $this->setSubject(new aam_Control_Role($role_id, $blog_id));
            }
        }
    }

    public function isAnonimus() {
        return (trim(aam_Core_Request::request('role')) == 'visitor' ? true : false);
    }

    public function getSubject() {
        return $this->_subject;
    }

    public function setSubject(aam_Control_Subject $subject) {
        $this->_subject = $subject;
    }

    public function loadTemplate($tmpl_path) {
        ob_start();
        require_once($tmpl_path);
        $content = ob_get_contents();
        ob_clean();

        return $content;
    }

}
