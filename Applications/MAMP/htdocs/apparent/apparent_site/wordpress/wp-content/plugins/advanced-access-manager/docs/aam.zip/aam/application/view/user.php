<?php
/**
 * ======================================================================
 * LICENSE: This file is subject to the terms and conditions defined in *
 * file 'license.txt', which is part of this source code package.       *
 * ======================================================================
 */

class aam_View_User extends aam_View_Abstract
{

    public function content()
    {
        return $this->loadTemplate(dirname(__FILE__) . '/tmpl/user.phtml');
    }

    public function retrieveList()
    {
        //get total number of users
        $total = count_users();
        $result = $this->query();
        $response = array(
            'iTotalRecords' => $total['total_users'],
            'iTotalDisplayRecords' => $result->get_total(),
            'sEcho' => aam_Core_Request::request('sEcho'),
            'aaData' => array(),
        );
        foreach ($result->get_results() as $user) {
            $response['aaData'][] = array(
                $user->ID,
                $user->user_login,
                ($user->display_name ? $user->display_name : $user->user_nicename),
                '',
                $user->user_status
            );
        }

        return json_encode($response);
    }

    public function query()
    {
        if ($search = trim(aam_Core_Request::request('sSearch'))) {
            $search = "{$search}*";
        }
        $args = array(
            'number' => '',
            'blog_id' => aam_Core_Request::request('blog'),
            'role' => aam_Core_Request::request('role'),
            'fields' => 'all',
            'number' => aam_Core_Request::request('iDisplayLength'),
            'offset' => aam_Core_Request::request('iDisplayStart'),
            'search' => $search,
            'search_columns' => array('user_login', 'user_email', 'display_name'),
            'orderby' => 'user_nicename',
            'order' => 'ASC'
        );

        return new WP_User_Query($args);
    }

    public function edit()
    {
        $id = aam_Core_Request::post('id', 0);
        if (current_user_can('add_users') && ($user_id = edit_user($id))) {
            if (is_wp_error($user_id)) {
                $response = array('status' => 'failure');
            } else {
                $response = array('status' => 'success', 'user' => $user_id);
            }
        } else {
            $response = array('status' => 'failure');
        }

        return json_encode($response);
    }

    public function read()
    {
        if (current_user_can('edit_users')) {
            $user = get_user_to_edit(aam_Core_Request::post('user'));

            $user_roles = array_intersect(array_values($user->roles), array_keys(get_editable_roles()));
            $user_role = array_shift($user_roles);

            $response = array(
                'status' => 'success',
                'data' => array(
                    'user_login' => $user->user_login,
                    'user_email' => $user->user_email,
                    'first_name' => $user->first_name,
                    'last_name' => $user->last_name,
                    'display_name' => $user->display_name,
                    'role' => $user_role
                )
            );
        } else {
            $response = array('status' => 'failure');
        }

        return json_encode($response);
    }

    public function block()
    {
        global $wpdb;

        $user = new WP_User(aam_Core_Request::post('id'));

        if ($user && current_user_can('edit_users') && ($user->ID != get_current_user_id())) {
            $status = ($user->user_status == 0 ? 1 : 0);
            $wpdb->update(
                $wpdb->users, array('user_status' => $status), array('ID' => $user->ID)
            );
            clean_user_cache($user);
            $response = array('status' => 'success', 'user_status' => $status);
        } else {
            $response = array('status' => 'failure');
        }

        return json_encode($response);
    }

    public function delete()
    {
        $user_id = aam_Core_Request::post('id');
        if (current_user_can('delete_users') && ($user_id !== get_current_user_id()) && wp_delete_user($user_id)) {
            $response = array('status' => 'success');
        } else {
            $response = array('status' => 'failure');
        }

        return json_encode($response);
    }

}