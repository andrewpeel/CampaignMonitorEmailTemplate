<?php

/**
  Plugin Name: Advanced Access Manager
  Description: Manage Access to WordPress Backend and Frontend.
  Version: 2.0
  Author: Vasyl Martyniuk <support@wpaam.com>
  Author URI: http://www.wpaam.com
 */
/**
 * ======================================================================
 * LICENSE: This file is subject to the terms and conditions defined in *
 * file 'license.txt', which is part of this source code package.       *
 * ======================================================================
 */
require_once('aam_config.php');

/**
 * Main Plugin Class
 *
 * Responsible for initialization and handling user requests to Advanced Access
 * Manager
 *
 * @package AAM
 * @author Vasyl Martyniuk <support@wpaam.com>
 * @copyright Copyright C 2013 Vasyl Martyniuk
 * @license GNU General Public License {@link http://www.gnu.org/licenses/}
 */
class aam {

    /**
     * Single instance of itself
     *
     * @var aam
     *
     * @access private
     */
    private static $_aam = null;

    /**
     * User Subject
     * 
     * @var aam_Control_User
     * 
     * @access private 
     */
    private $_user = null;

    /**
     * Initialize the AAM Object
     *
     * @return void
     *
     * @access protected
     */
    protected function __construct() {
        //initialize the user subject
        $this->setUser(new aam_Control_User(
                get_current_user_id(), get_current_blog_id()
        ));

        if (is_admin()) {
            //print required JS & CSS
            add_action('admin_print_scripts', array($this, 'printScripts'));
            add_action('admin_print_styles', array($this, 'printStyles'));

            //manager Admin Menu
            add_action('admin_menu', array($this, 'adminMenu'), 999);
            //manager AAM Features Content rendering
            add_action('admin_action_features', array($this, 'features'));
            //manager AAM Ajax Requests
            add_action('wp_ajax_aam', array($this, 'ajax'));
            //manager WordPress metaboxes
            add_action("do_meta_boxes", array($this, 'metaboxes'), 999, 3);
            add_action("add_meta_boxes", array($this, 'filterMetaboxes'), 999, 2);
            //manager user search and authentication control
            add_filter('user_search_columns', array($this, 'searchColumns'));
            add_filter('wp_authenticate_user', array($this, 'authenticate'), 1, 2);
            //terms & post restriction handlers
            //add_action('edited_term', array($this, 'editedTerm'), 999, 3);
            //add_action('post_updated', array($this, 'postUpdate'), 10, 3);
            add_filter('page_row_actions', array($this, 'postRowActions'), 10, 2);
            add_filter('post_row_actions', array($this, 'postRowActions'), 10, 2);
            add_filter('tag_row_actions', array($this, 'tagRowActions'), 10, 2);
            add_action('admin_action_edit', array($this, 'adminActionEdit'), 10);
        } else {
            //control WordPress frontend
            add_action('wp', array($this, 'wp'), 999);
        }
        //use some internal hooks to extend functionality
        add_filter('aam_access_objects', array($this, 'internalHooks'), 1, 2);
    }

    public function getPost() {
        if (get_post()) {
            $post = get_post();
        } elseif ($post_id = aam_Core_Request::get('post')) {
            $post = get_post($post_id);
        } elseif ($post_id = aam_Core_Request::get('post_ID')) {
            $post = get_post($post_id);
        } else {
            $post = null;
        }

        return $post;
    }

    public function adminActionEdit() {
        $restrict = false;
        $user = $this->getUser();
        if (aam_Core_Request::request('taxonomy')) {
            if ($user->getObject(aam_Control_Term::UID, aam_Core_Request::request('tag_ID'))
                            ->has('backend', aam_Control_Post::ACTION_EDIT)) {
                $restrict = true;
            }
        } elseif ($post = $this->getPost()) {
            if ($user->getObject(aam_Control_Post::UID, $post->ID)
                            ->has('backend', aam_Control_Post::ACTION_EDIT)) {
                $restrict = true;
            }
        }

        if ($restrict) {
            die('Nope');
        }
    }
    
    public function tagRowActions($actions, $term) {
        $user = $this->getUser();
        //filter edit menu
        if ($user->getObject(aam_Control_Term::UID, $term->term_id)
                        ->has('backend', aam_Control_Post::ACTION_EDIT)) {
            if (isset($actions['edit'])) {
                unset($actions['edit']);
            }
            if (isset($actions['inline hide-if-no-js'])) {
                unset($actions['inline hide-if-no-js']);
            }
        }

        //filter delete menu
        if ($user->getObject(aam_Control_Term::UID, $term->term_id)
                        ->has('backend', aam_Control_Post::ACTION_DELETE)) {
            if (isset($actions['delete'])) {
                unset($actions['delete']);
            }
        }

        return $actions;
    }

    public function postRowActions($actions, $post) {
        $user = $this->getUser();
        //filter edit menu
        if ($user->getObject(aam_Control_Post::UID, $post->ID)
                        ->has('backend', aam_Control_Post::ACTION_EDIT)) {
            if (isset($actions['edit'])) {
                unset($actions['edit']);
            }
            if (isset($actions['inline hide-if-no-js'])) {
                unset($actions['inline hide-if-no-js']);
            }
        }
        //filter trash menu
        if ($user->getObject(aam_Control_Post::UID, $post->ID)
                        ->has('backend', aam_Control_Post::ACTION_TRASH)) {
            if (isset($actions['trash'])) {
                unset($actions['trash']);
            }
        }

        //filter delete menu
        if ($user->getObject(aam_Control_Post::UID, $post->ID)
                        ->has('backend', aam_Control_Post::ACTION_DELETE)) {
            if (isset($actions['delete'])) {
                unset($actions['delete']);
            }
        }

        return $actions;
    }

    public function wp() {
        global $wp_query, $post;

        $restrict = false;

        if (is_category()) {
            $category = $wp_query->get_queried_object();
            if ($this->getUser()->getObject(
                            aam_Control_Term::UID, $category->term_id
                    )->has('frontend', aam_Control_Term::ACTION_BROWSE)) {
                $restrict = true;
            }
        } elseif (!$wp_query->is_home() && ($post instanceof WP_Post)) {
            if ($this->getUser()->getObject(
                            aam_Control_Post::UID, $post->ID
                    )->has('frontend', aam_Control_Post::ACTION_READ)) {
                $restrict = true;
            }
        }

        if ($restrict) {
            die('Nope');
        }
    }

    public function internalHooks($objects, $subject) {
        $objects[aam_Control_Event::UID] = new aam_Control_Event($subject);
        $objects[aam_Control_ConfigPress::UID] = new aam_Control_ConfigPress(
                $subject
        );

        return $objects;
    }

    public function editedTerm($term_id, $tt_id, $taxonomy) {
        $model = new aam_Control_Term($term_id, $taxonomy);
        $model->delete('all');
    }

    public function postUpdate($post_ID, $post_after, $post_before = null) {
        $model = new aam_Control_Post($post_ID);
        $model->delete('all');
    }

    public function searchColumns($columns) {
        $columns[] = 'display_name';

        return $columns;
    }

    public function authenticate($user) {
        if ($user->user_status == 1) {
            $user = new WP_Error();
            $user->add(
                    'authentication_failed', '<strong>ERROR</strong>: User is blocked'
            );
        }

        return $user;
    }

    /**
     * Print necessary styles
     *
     * @return void
     *
     * @access public
     */
    public function printStyles() {
        if (aam_Core_Request::get('page') == 'aam') {
            wp_enqueue_style('dashboard');
            wp_enqueue_style('global');
            wp_enqueue_style('wp-admin');
            wp_enqueue_style('aam-ui-style', AAM_MEDIA_URL . 'css/jquery-ui.css');
            wp_enqueue_style('aam-style', AAM_MEDIA_URL . 'css/aam.css');
            wp_enqueue_style('aam-datatables', AAM_MEDIA_URL . 'css/jquery.dt.css');
            wp_enqueue_style('aam-codemirror', AAM_MEDIA_URL . 'css/codemirror.css');
            wp_enqueue_style('aam-treeview', AAM_MEDIA_URL . 'css/jquery.treeview.css');
        }
    }

    /**
     * Print necessary scripts
     *
     * @return void
     *
     * @access public
     */
    public function printScripts() {
        if (aam_Core_Request::get('page') == 'aam') {
            wp_enqueue_script('postbox');
            wp_enqueue_script('dashboard');
            wp_enqueue_script('aam-admin', AAM_MEDIA_URL . 'js/aam.js');
            wp_enqueue_script('aam-datatables', AAM_MEDIA_URL . 'js/jquery.dt.js');
            wp_enqueue_script('aam-codemirror', AAM_MEDIA_URL . 'js/codemirror.js');
            wp_enqueue_script('aam-cmini', AAM_MEDIA_URL . 'js/properties.js');
            wp_enqueue_script('aam-treeview', AAM_MEDIA_URL . 'js/jquery.treeview.js');
            wp_enqueue_script('jquery-ui-core');
            wp_enqueue_script('jquery-effects-core');
            wp_enqueue_script('jquery-ui-widget');
            wp_enqueue_script('jquery-ui-tabs');
            wp_enqueue_script('jquery-ui-accordion');
            wp_enqueue_script('jquery-ui-progressbar');
            wp_enqueue_script('jquery-ui-dialog');
            wp_enqueue_script('jquery-ui-button');
            wp_enqueue_script('jquery-ui-sortable');
            wp_enqueue_script('jquery-ui-menu');
            wp_enqueue_script('jquery-effects-highlight');

            $localization = array(
                'nonce' => wp_create_nonce('aam_ajax'),
                'dashboardURI' => admin_url('index.php'),
                'ajaxurl' => admin_url('admin-ajax.php'),
                'addUserURI' => admin_url('user-new.php'),
                'editUserURI' => admin_url('user-edit.php')
            );

            wp_localize_script('aam-admin', 'aamLocal', $localization);
        }
    }

    public function features() {
        check_ajax_referer('aam_ajax');

        $model = new aam_View_Manager;
        $model->retrieveFeatures();
        die();
    }

    public function ajax() {
        check_ajax_referer('aam_ajax');

        $model = new aam_View_Ajax;
        echo $model->run();
        die();
    }

    public function metaboxes($post_type) {
        if (aam_Core_Request::get('aam_meta_init')) {
            $model = new aam_View_Metabox;
            $model->run($post_type);
        }
    }

    public function filterMetaboxes($post_type, $post) {
        $this->getUser()->getObject(aam_Control_Metabox::UID)->filter(
                $post_type, $post
        );
    }

    /**
     * Add Admin Menu
     *
     * @return void
     *
     * @access public
     */
    public function adminMenu() {
        //register the menu
        add_menu_page(
                __('AAM', 'aam'), __('AAM', 'aam'), 'administrator', 'aam', array($this, 'content'), AAM_BASE_URL . 'active-menu.png'
        );

        //filter admin menu
        $this->getUser()->getObject(aam_Control_Menu::UID)->filter();
    }

    /**
     * Render Main Content page
     *
     * @return void
     *
     * @access public
     */
    public function content() {
        $manager = new aam_View_Manager();
        echo $manager->run();
    }

    /**
     * Initialize the AAM plugin
     *
     * @return void
     *
     * @access public
     * @static
     */
    public static function initialize() {
        if (is_null(self::$_aam)) {
            self::$_aam = new self;
        }
    }

    /**
     * Get Current User Subject
     * 
     * @return aam_Control_User
     * 
     * @access public
     */
    public function getUser() {
        return $this->_user;
    }

    /**
     * Set Current User Subject
     * 
     * @param aam_Control_User $user
     * 
     * @return void
     * 
     * @access public
     */
    public function setUser(aam_Control_User $user) {
        $this->_user = $user;
    }

}

add_action('init', 'aam::initialize');
