<?php

class aam_Control_Term extends aam_Control_Object {

    const UID = 'term';

    private $_term = null;
    private $_option = array();

    public function save(array $params) {
        if (is_array($params)) {
            $this->getSubject()->updateOption(
                    $params, self::UID, $this->getTerm()->term_id
            );
        }
    }

    public function init($object_id = 0) {
        if ($this->getObjectId() !== $object_id) {
            //initialize term first
            $this->setTerm(get_term($object_id, $this->getTaxonomy($object_id)));
            if ($this->getTerm()) {
                $access = $this->getSubject()->readOption(
                        self::UID, $this->getTerm()->term_id
                );
                if (empty($access)) {
                    //try to get any parent restriction
                    $this->setOption($this->inheritAccess($this->getTerm()->parent));
                } else {
                    $this->setOption($access);
                }
            } else {
                aam_Core_Console::write("Term {$object_id} does not exist");
            }
        }
    }

    private function inheritAccess($term_id) {
        $term = new aam_Control_Term($this->getSubject(), $term_id);
        if ($term->getTerm()) {
            $access = $term->getOption();
            if (empty($access) && $term->getTerm()->parent) {
                $this->inheritAccess($term->getTerm()->parent);
            } elseif (!empty($access)) {
                $access['inherited'] = true;
            }
        } else {
            $access = array();
        }

        return $access;
    }

    private function getTaxonomy($object_id) {
        global $wpdb;

        $query = "SELECT taxonomy FROM {$wpdb->term_taxonomy} ";
        $query .= "WHERE term_id = {$object_id}";

        return $wpdb->get_var($query);
    }

    public function setTerm($term) {
        $this->_term = $term;
    }

    public function getTerm() {
        return $this->_term;
    }

    public function setOption(array $option) {
        $this->_option = $option;
    }

    public function getOption() {
        return $this->_option;
    }

    public function has($area, $action) {
        $response = false;
        if (isset($this->_option[$area][$action])) {
            $response = (intval($this->_option[$area][$action]) ? true : false);
        }

        return $response;
    }

}
