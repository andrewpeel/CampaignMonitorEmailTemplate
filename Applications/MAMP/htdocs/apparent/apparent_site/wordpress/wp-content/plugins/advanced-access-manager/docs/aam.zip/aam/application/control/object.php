<?php

abstract class aam_Control_Object {

    private $_subject = null;
    private $_object_id = null;

    public function __construct(aam_Control_Subject $subject, $object_id = null) {
        $this->setSubject($subject);
        if (!is_null($object_id)){
            $this->init($object_id);
        }
    }

    abstract public function init($object_id = '');

    abstract public function save(array $params);

    public function setSubject(aam_Control_Subject $subject) {
        $this->_subject = $subject;
    }

    public function getSubject() {
        return $this->_subject;
    }

    public function setObjectId($object_id) {
        $this->_object_id = $object_id;
    }

    public function getObjectId() {
        return $this->_object_id;
    }

}
