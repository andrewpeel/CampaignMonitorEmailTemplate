<?php
/**
 * ======================================================================
 * LICENSE: This file is subject to the terms and conditions defined in *
 * file 'license.txt', which is part of this source code package.       *
 * ======================================================================
 */

class aam_View_Visitor extends aam_View_Abstract
{

    public function content()
    {
        return $this->loadTemplate(dirname(__FILE__) . '/tmpl/visitor.phtml');
    }

}