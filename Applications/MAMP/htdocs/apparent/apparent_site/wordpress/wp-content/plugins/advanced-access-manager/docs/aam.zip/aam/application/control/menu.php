<?php

class aam_Control_Menu extends aam_Control_Object {

    const UID = 'menu';

    private $_option = array();
    private $_order = array();

    public function filter() {
        global $menu, $submenu;

        //filter menu & submenu first
        $random = uniqid('aam_'); //oopsie, random capability - no access
        //let's go and iterate menu & submenu
        foreach ($menu as $id => $item) {
            if ($this->has($item[2])) {
                $menu[$id][1] = $random;
            }
            //go to submenu
            if (isset($submenu[$item[2]])) {
                foreach ($submenu[$item[2]] as $sid => $sub_item) {
                    if ($this->has($sub_item[2])) {
                        $submenu[$item[2]][$sid][1] = $random;
                    }
                }
            }
        }
    }

    public function reorder() {
        global $menu;

        //reorganize menu
        $new_order = array();
        if (!empty($this->_order)) {
            foreach ($this->_order as $menu_id) {
                array_shift($this->_order);
                foreach ($menu as $id => $item) {
                    if ($item[2] == $menu_id) {
                        $new_order[$id] = $item;
                        unset($menu[$id]);
                        break;
                    } elseif (!in_array($item[2], $this->_order)) {
                        $new_order[$id] = $item;
                        unset($menu[$id]);
                    }
                }
            }
        } else {
            $new_order = null;
        }

        return $new_order;
    }

    public function save(array $params) {
        $menu = (isset($params[self::UID]) ? $params[self::UID] : array());

        if (is_array($menu)) {
            $this->getSubject()->updateOption($menu, self::UID);
        }
    }

    public function init($object_id = '') {
        if ($this->getObjectId() !== $object_id) {
            $menu = $this->getSubject()->readOption(self::UID);
            if (!is_array($menu)) {
                $menu = array();
            }

            $this->setOption($menu);
        }
    }

    public function setOption(array $option) {
        $this->_option = $option;
        if (isset($this->_option['order'])) {
            $this->_order = $this->_option['order'];
            unset($this->_option['order']);
        }
    }

    public function getOption() {
        return $this->_option;
    }

    public function has($menu) {
        $response = false;
        if (isset($this->_option[$menu])) {
            $response = (intval($this->_option[$menu]) ? true : false);
        }

        return $response;
    }

}
