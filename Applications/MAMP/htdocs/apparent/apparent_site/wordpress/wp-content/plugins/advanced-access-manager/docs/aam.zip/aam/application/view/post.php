<?php

/**
 * ======================================================================
 * LICENSE: This file is subject to the terms and conditions defined in *
 * file 'license.txt', which is part of this source code package.       *
 * ======================================================================
 */
class aam_View_Post extends aam_View_Abstract {

    private $_post_type = 'post';
    private $_term = 0;

    public function __construct() {
        parent::__construct();
        $this->_post_type = aam_Core_Request::request('post_type');
        $this->_term = intval(aam_Core_Request::request('term'));
    }

    public function retrievePostTypeList() {
        global $wp_post_types;

        $response = array(
            'aaData' => array()
        );

        if (is_array($wp_post_types)) {
            foreach ($wp_post_types as $post_type => $data) {
                //show only list of post type which have User Interface
                if ($data->show_ui) {
                    $response['aaData'][] = array(
                        $post_type,
                        $data->label,
                        ''
                    );
                }
            }
        }

        return json_encode($response);
    }

    public function retrievePostList() {
        global $wp_post_statuses, $wp_post_types;

        $term = trim(aam_Core_Request::request('term'));

        if (empty($term)) {
            $post_type = 'post';
        } elseif (isset($wp_post_types[$term])) {
            $post_type = $term;
            $term = '';
        } else {
            $post_type = '';
        }

        $args = array(
            'numberposts' => aam_Core_Request::request('iDisplayLength'),
            'offset' => aam_Core_Request::request('iDisplayStart'),
            'category' => $term,
            'post_type' => $post_type,
            's' => aam_Core_Request::request('sSearch'),
            'post_status' => array()
        );

        $argsAll = array(
            'numberposts' => '999999',
            'fields' => 'ids',
            'category' => $term,
            'post_type' => $post_type,
            's' => aam_Core_Request::request('sSearch'),
            'post_status' => array()
        );

        foreach ($wp_post_statuses as $status => $data) {
            if ($data->show_in_admin_status_list) {
                $args['post_status'][] = $status;
                $argsAll['post_status'][] = $status;
            }
        }

        $total = 0;
        foreach (wp_count_posts($post_type) as $status => $number) {
            if ($wp_post_statuses[$status]->show_in_admin_status_list) {
                $total += $number;
            }
        }

        //get displayed total
        $displayTotal = count(get_posts($argsAll));

        $response = array(
            'iTotalRecords' => $total,
            'iTotalDisplayRecords' => $displayTotal,
            'sEcho' => aam_Core_Request::request('sEcho'),
            'aaData' => array(),
        );

        foreach (get_posts($args) as $post) {
            $response['aaData'][] = array(
                $post->ID,
                $post->post_status,
                get_edit_post_link($post->ID),
                $post->post_title,
                $wp_post_statuses[$post->post_status]->label,
                ''
            );
        }

        return json_encode($response);
    }

    public function getPostTree() {
        global $wp_post_types;

        $type = $_REQUEST['root'];
        $tree = array();

        if ($type == "source") {
            if (is_array($wp_post_types)) {
                foreach ($wp_post_types as $post_type => $data) {
                    //show only list of post type which have User Interface
                    if ($data->show_ui) {
                        $tree[] = (object) array(
                                    'text' => $data->label,
                                    'expanded' => FALSE,
                                    'hasChildren' => TRUE,
                                    'id' => $post_type,
                                    'classes' => 'important',
                        );
                    }
                }
            }
        } else {
            if (preg_match('/^[\d]+$/', $type)) {
                $taxonomy = $this->getTaxonomyByTerm($type);
                $tree = $this->buildBranch(NULL, $taxonomy, $type);
            } else {
                $tree = $this->buildBranch($type);
            }
        }

        if (!count($tree)) {
            $tree[] = (object) array(
                        'text' => '<i>' . __('[empty]', 'aam') . '</i>',
                        'hasChildren' => FALSE,
                        'classes' => 'post-ontree',
                        'id' => 'empty-' . uniqid()
            );
        }

        return json_encode($tree);
    }

    protected function getTaxonomyByTerm($term_id) {
        global $wpdb;

        if ($term_id) {
            $query = "SELECT taxonomy FROM {$wpdb->term_taxonomy} ";
            $query .= "WHERE term_id = {$term_id}";
            $result = $wpdb->get_var($query);
        } else {
            $result = FALSE;
        }

        return $result;
    }

    private function buildBranch($post_type, $taxonomy = FALSE, $parent = 0) {
        $tree = array();
        if (!$parent && !$taxonomy) { //root of a branch
            $tree = $this->buildCategories($post_type);
        } elseif ($taxonomy) { //build sub categories
            $tree = $this->buildCategories('', $taxonomy, $parent);
        }

        return $tree;
    }

    private function buildCategories($post_type, $taxonomy = FALSE, $parent = 0) {

        $tree = array();

        if ($parent) {
            //$taxonomy = $this->get_taxonomy_get_term($parent);
            //firstly render the list of sub categories
            $cat_list = get_terms(
                    $taxonomy, array(
                'get' => 'all',
                'parent' => $parent,
                'hide_empty' => FALSE
                    )
            );
            if (is_array($cat_list)) {
                foreach ($cat_list as $category) {
                    $tree[] = $this->buildCategory($category);
                }
            }
        } else {
            $taxonomies = get_object_taxonomies($post_type);
            foreach ($taxonomies as $taxonomy) {
                if (is_taxonomy_hierarchical($taxonomy)) {
                    $term_list = get_terms($taxonomy, array(
                        'parent' => $parent,
                        'hide_empty' => FALSE
                    ));
                    if (is_array($term_list)) {
                        foreach ($term_list as $term) {
                            $tree[] = $this->buildCategory($term);
                        }
                    }
                }
            }
        }

        return $tree;
    }

    private function buildCategory($category) {
        $branch = (object) array(
                    'text' => $category->name,
                    'expanded' => FALSE,
                    'classes' => 'important folder',
        );
        if ($this->hasCategoryChilds($category)) {
            $branch->hasChildren = TRUE;
        } else {
            $branch->hasChildren = FALSE;
        }
        $branch->id = $category->term_id;

        return $branch;
    }

    /**
     * Check if category has children
     *
     * @param int category ID
     * @return bool TRUE if has
     */
    protected function hasCategoryChilds($cat) {
        global $wpdb;

        //get number of categories
        $query = "SELECT COUNT(*) FROM {$wpdb->term_taxonomy} WHERE parent={$cat->term_id}";
        $counter = $wpdb->get_var($query);

        return ($counter ? TRUE : FALSE);
    }

    public function getPostBreadcrumb() {
        global $wp_post_types, $wp_taxonomies;

        $id = aam_Core_Request::post('id');
        $response = array();
        if (preg_match('/^[\d]+$/', $id)) {
            $taxonomy = $this->getTaxonomyByTerm($id);
            //get post type
            if (isset($wp_taxonomies[$taxonomy])) {
                $post_type = $wp_taxonomies[$taxonomy]->object_type[0];
                if (isset($wp_post_types[$post_type])) {
                    $response['post_type'] = $post_type;
                    $response['term'] = $id;
                    $response['link'] = get_edit_term_link($id, $taxonomy);
                    $term = get_term($id, $taxonomy);
                    $tree = $this->renderBreadcrumbTree($term, array());
                    $tree[] = array($post_type, $wp_post_types[$post_type]->label);
                    $response['breadcrumb'] = array_reverse($tree);
                }
            }
        } else {
            if (isset($wp_post_types[$id])) {
                $response = array(
                    'post_type' => $id,
                    'term' => 0,
                    'breadcrumb' => array(
                        array($id, $wp_post_types[$id]->label),
                        array('#', __('All', 'aam'))
                    )
                );
            } else {
                $response = array(
                    'term' => '',
                    'breadcrumb' => array(
                        array('post', $wp_post_types['post']->label),
                        array('#', __('All', 'aam'))
                    )
                );
            }
        }

        return json_encode($response);
    }

    protected function renderBreadcrumbTree($term, $tree) {
        $tree[] = array($term->term_id, $term->name);
        if ($term->parent) {
            $tree = $this->renderBreadcrumbTree(
                    get_term($term->parent, $term->taxonomy), $tree
            );
        }

        return $tree;
    }

    public function content() {
        return $this->loadTemplate(dirname(__FILE__) . '/tmpl/post.phtml');
    }

    public function saveAccess() {
        $object_id = aam_Core_Request::post('id');
        if ($access = aam_Core_Request::post('term')) {
            if (aam_Core_Request::post('descend') == '1') {
                $access['sub'] = aam_Core_Request::post('post');
            }
            $object = $this->getSubject()->getObject(aam_Control_Term::UID, $object_id);
        } else {
            $access = aam_Core_Request::post('post');
            $object = $this->getSubject()->getObject(aam_Control_Post::UID, $object_id);
        }
        $object->save($access);

        return json_encode(array('status' => 'success'));
    }

    public function getAccess() {
        $type = aam_Core_Request::post('type');
        $object_id = aam_Core_Request::post('id');

        if ($type === 'term') {
            $object = $this->getSubject()->getObject(aam_Control_Term::UID, $object_id);
        } else {
            $object = $this->getSubject()->getObject(aam_Control_Post::UID, $object_id);
        }

        return json_encode($object->getOption());
    }

    public function clearAccess() {
        $type = aam_Core_Request::post('type');
        $object_id = aam_Core_Request::post('id');

        if ($type === 'term') {
            $object = $this->getSubject()->getObject(aam_Control_Term::UID, $object_id);
        } else {
            $object = $this->getSubject()->getObject(aam_Control_Post::UID, $object_id);
        }

        return json_encode(array(
            'status' => ($object->delete() ? 'success' : 'failure')
        ));
    }

}
