<?php

class aam_Control_Post extends aam_Control_Object {

    const UID = 'post';
    const ACTION_COMMENT = 'comment';
    const ACTION_READ = 'read';
    const ACTION_TRASH = 'trash';
    const ACTION_DELETE = 'delete';
    const ACTION_EDIT = 'edit';
    const ACTION_PUBLISH = 'publish';

    private $_post;
    private $_option = array();

    public function save(array $params) {
        if (is_array($params)) {
            update_post_meta($this->getPost()->ID, $this->getOptionName(), $params);
        }
    }

    protected function getOptionName() {
        $subject = $this->getSubject();
        if ($subject::UID === aam_Control_User::UID) {
            $meta_key = 'aam_' . self::UID . '_access_' . aam_Control_User::UID;
            $meta_key .= '_' . $this->getSubject()->getId();
        } else {
            $meta_key = 'aam_' . self::UID . '_access_' . aam_Control_Role::UID;
            $meta_key .= '_' . $this->getSubject()->getId();
        }

        return $meta_key;
    }

    public function init($object_id = 0) {
        if ($this->getObjectId() !== $object_id) {
            $this->setPost(get_post($object_id));
            $this->read();
        } else {
            aam_Core_Console::write("Post {$object_id} does not exist");
        }
    }

    public function read() {
        $access = get_post_meta($this->getPost()->ID, $this->getOptionName(), true);
        //try to inherit it from parent category
        if (empty($access)) {
            $terms = $this->retrievePostTerms();
            //use only first term for inheritance
            $term_id = array_shift($terms);
            //try to get any parent access
            $access = $this->inheritAccess($term_id);
        }

        $this->setOption($access);
    }

    public function delete() {
        return delete_post_meta($this->getPost()->ID, $this->getOptionName());
    }

    private function retrievePostTerms() {
        $taxonomies = get_object_taxonomies($this->getPost());
        if (is_array($taxonomies) && count($taxonomies)) {
            //filter taxonomies to hierarchical only
            $filtered = array();
            foreach ($taxonomies as $taxonomy) {
                if (is_taxonomy_hierarchical($taxonomy)) {
                    $filtered[] = $taxonomy;
                }
            }
            $terms = wp_get_object_terms(
                    $this->getPost()->ID, $filtered, array('fields' => 'ids')
            );
        } else {
            $terms = array();
        }

        return $terms;
    }

    private function inheritAccess($term_id) {
        $term = new aam_Control_Term($this->getSubject(), $term_id);
        $access = $term->getOption();
        if (isset($access['sub']) && $access['sub']) {
            $result = $access['sub'];
        } elseif ($term->getTerm()->parent) {
            $result = $this->inheritAccess($term->getTerm()->parent);
        } else {
            $result = array();
        }

        return $result;
    }

    public function setPost(WP_Post $post) {
        $this->_post = $post;
    }

    public function getPost() {
        return $this->_post;
    }

    public function setOption(array $option) {
        $this->_option = $option;
    }

    public function getOption() {
        return $this->_option;
    }

    public function has($area, $action) {
        $response = false;
        if (isset($this->_option[$area][$action])) {
            $response = (intval($this->_option[$area][$action]) ? true : false);
        }

        return $response;
    }

}
