<?php

class aam_Control_Capability extends aam_Control_Object {

    const UID = 'capability';

    private $_capabilities = array();

    public function save(array $params) {
        $capabilities = (isset($params[self::UID]) ? $params[self::UID] : array());

        if (is_array($capabilities)) {
            foreach ($capabilities as $capability => $grant) {
                $this->getSubject()->updateCapability(
                        $capability, (intval($grant) ? true : false)
                );
            }
        }
    }

    public function init($object_id = '') {
        if ($this->getObjectId() !== $object_id) {
            $capabilities = $this->getSubject()->getCapabilities();
            if (!is_array($capabilities)) {
                $capabilities = array();
            }
            $this->setCapabilities($capabilities);
        }
    }

    public function setCapabilities(array $capabilities) {
        $this->_capabilities = $capabilities;
    }

    public function getCapabilities() {
        return $this->_capabilities;
    }

    public function has($capability) {
        return $this->getSubject()->hasCapability($capability);
    }

}
