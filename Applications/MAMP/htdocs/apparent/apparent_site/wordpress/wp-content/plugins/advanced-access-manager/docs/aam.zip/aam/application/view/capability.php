<?php

/**
 * ======================================================================
 * LICENSE: This file is subject to the terms and conditions defined in *
 * file 'license.txt', which is part of this source code package.       *
 * ======================================================================
 */
class aam_View_Capability extends aam_View_Abstract {

    private $_groups = array(
        'system' => array(
            'level_0', 'level_1', 'level_2', 'level_3', 'level_4', 'level_5',
            'level_6', 'level_7', 'level_8', 'level_9', 'level_10'
        ),
        'post' => array(
            'delete_others_pages', 'delete_others_posts', 'delete_pages',
            'delete_posts', 'delete_private_pages', 'delete_private_posts',
            'delete_published_pages', 'delete_published_posts', 'edit_others_pages',
            'edit_others_posts', 'edit_pages', 'edit_private_posts',
            'edit_private_pages', 'edit_posts', 'edit_published_pages',
            'edit_published_posts', 'publish_pages', 'publish_posts', 'read',
            'read_private_pages', 'read_private_posts', 'edit_permalink'
        ),
        'comment' => array(
            'delete_comment', 'approve_comment', 'edit_comment', 'moderate_comments',
            'quick_edit_comment', 'spam_comment', 'reply_comment', 'trash_comment',
            'unapprove_comment', 'untrash_comment', 'unspam_comment',
        ),
        'backend' => array(
            'aam_manage', 'activate_plugins', 'add_users', 'create_users',
            'delete_users', 'delete_themes', 'edit_dashboard', 'edit_files',
            'edit_plugins', 'edit_theme_options', 'edit_themes', 'edit_users',
            'export', 'import', 'install_plugins', 'install_themes', 'list_users',
            'manage_options', 'manage_links', 'manage_categories', 'promote_users',
            'unfiltered_html', 'unfiltered_upload', 'update_themes', 'update_plugins',
            'update_core', 'upload_files', 'delete_plugins', 'remove_users',
            'switch_themes'
        )
    );

    public function retrieveList() {
        $response = array(
            'aaData' => array()
        );

        $subject = $this->getSubject();
        if ($subject::UID === aam_Control_Role::UID) {
            //prepare list of all capabilities
            $roles = new WP_Roles();
            $caps = array();
            foreach ($roles->role_objects as $role) {
                $caps = array_merge($caps, $role->capabilities);
            }
            //init all caps
            foreach ($caps as $capability => $grant) {
                $response['aaData'][] = array(
                    $capability,
                    ($subject->hasCapability($capability) ? 1 : 0),
                    $this->getGroup($capability),
                    $this->getHumanText($capability),
                    ''
                );
            }
        } else {
            foreach ($subject->getCapabilities() as $capability => $grant) {
                $response['aaData'][] = array(
                    $capability,
                    intval($grant),
                    $this->getGroup($capability),
                    $this->getHumanText($capability),
                    ''
                );
            }
        }

        return json_encode($response);
    }

    public function retrieveRoleCapabilities() {
        return json_encode(array(
            'status' => 'success',
            'capabilities' => $this->getSubject()->getCapabilities()
        ));
    }

    public function addCapability() {
        $roles = new WP_Roles();
        $capability = trim(aam_Core_Request::post('capability'));

        if ($capability) {
            $normalized = str_replace(' ', '_', strtolower($capability));
            //add the capability to administrator's role as default behavior
            $roles->add_cap('administrator', $normalized);
            $response = array('status' => 'success', 'capability' => $normalized);
        } else {
            $response = array('status' => 'failure');
        }

        return json_encode($response);
    }

    public function deleteCapability() {
        $roles = new WP_Roles();
        $capability = trim(aam_Core_Request::post('capability'));

        if ($capability) {
            foreach ($roles->role_objects as $role) {
                $role->remove_cap($capability);
            }
            $response = array('status' => 'success');
        } else {
            $response = array('status' => 'failure');
        }

        return json_encode($response);
    }

    protected function getHumanText($text) {
        $parts = preg_split('/_/', $text);
        if (is_array($parts)) {
            foreach ($parts as &$part) {
                $part = ucfirst($part);
            }
        }

        return implode(' ', $parts);
    }

    protected function getGroup($capability) {
        if (in_array($capability, $this->_groups['system'])) {
            $response = 'System';
        } elseif (in_array($capability, $this->_groups['post'])) {
            $response = 'Post & Page';
        } elseif (in_array($capability, $this->_groups['comment'])) {
            $response = 'Comment';
        } elseif (in_array($capability, $this->_groups['backend'])) {
            $response = 'Backend Interface';
        } else {
            $response = 'Miscelaneous';
        }

        return $response;
    }

    public function content() {
        return $this->loadTemplate(dirname(__FILE__) . '/tmpl/capability.phtml');
    }

}
