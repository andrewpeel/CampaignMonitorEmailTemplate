<?php
/**
 * ======================================================================
 * LICENSE: This file is subject to the terms and conditions defined in *
 * file 'license.txt', which is part of this source code package.       *
 * ======================================================================
 */

/**
 * Extension Repository handler
 *
 * @package AAM
 * @author Vasyl Martyniuk <martyniuk.vasyl@gmail.com>
 * @copyright Copyright C 2011 Vasyl Martyniuk
 * @license GNU General Public License {@link http://www.gnu.org/licenses/}
 */
class aam_Core_Repository {

    /**
     * Basedir to Extentions repository
     *
     * @var string
     *
     * @access private
     */
    private $_basedir = '';
    private $_cache = array();

    /**
     * Consturctor
     *
     * @return void
     *
     * @access public
     */
    public function __construct() {
        $this->_basedir = AAM_BASE_DIR . 'extension';
    }

    /**
     * Load active extensions
     *
     * @return void
     *
     * @access public
     */
    public function load() {
        //iterate through each active extension and load it
        foreach (scandir($this->_basedir) as $module) {
            if (!in_array($module, array('.', '..'))) {
                $this->bootstrapExtension($module);
            }
        }
    }

    /**
     * Bootstrap the Extension
     *
     * In case of any errors, the output can be found in console
     *
     * @param string $extension
     *
     * @return void
     *
     * @access protected
     */
    protected function bootstrapExtension($extension) {
        $bootstrap = $this->_basedir . "/{$extension}/bootstrap.php";
        if (file_exists($bootstrap) && !$this->_cache[$extension]) {
            $this->_cache[$extension] = require_once($bootstrap);
        }
    }

}