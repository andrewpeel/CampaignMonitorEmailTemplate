<?php
/**
 * ======================================================================
 * LICENSE: This file is subject to the terms and conditions defined in *
 * file 'license.txt', which is part of this source code package.       *
 * ======================================================================
 */

class aam_View_Role extends aam_View_Abstract
{

    public function content()
    {
        return $this->loadTemplate(dirname(__FILE__) . '/tmpl/role.phtml');
    }

    public function retrieveList()
    {
        //retrieve list of users
        $count = count_users();
        $user_count = $count['avail_roles'];

        //filter by name
        $search = strtolower(trim(aam_Core_Request::request('sSearch')));
        $filtered = array();
        $roles = get_editable_roles();
        foreach ($roles as $id => $role) {
            if (!$search || preg_match('/^' . $search . '/i', $role['name'])) {
                $filtered[$id] = $role;
            }
        }

        $response = array(
            'iTotalRecords' => count($roles),
            'iTotalDisplayRecords' => count($filtered),
            'sEcho' => aam_Core_Request::request('sEcho'),
            'aaData' => array(),
        );
        foreach ($filtered as $role => $data) {
            $users = (isset($user_count[$role]) ? $user_count[$role] : 0);
            $response['aaData'][] = array(
                $role,
                $users,
                $data['name'],
                ''
            );
        }

        return json_encode($response);
    }

    public function add()
    {
        $role = new WP_Roles;
        $role_id = 'aamrole_' . uniqid();
        if ($role->add_role($role_id, aam_Core_Request::post('role'))) {
            $response = array(
                'status' => 'success',
                'role' => $role_id
            );
        } else {
            $response = array('status' => 'failure');
        }

        return json_encode($response);
    }

    public function edit()
    {
        $role = new WP_Roles;
        $role_id = aam_Core_Request::post('id');
        $role_name = trim(aam_Core_Request::post('role'));
        if ($role_name && $role->get_role($role_id)) {
            $role->roles[$role_id]['name'] = $role_name;
            $status = aam_Core_API::updateBlogOption($role->role_key, $role->roles);
        } else {
            $status = false;
        }

        return json_encode(array('status' => ($status ? 'success' : 'failure')));
    }

    public function delete()
    {
        $role = new WP_Roles;
        $role_id = aam_Core_Request::post('role');
        $users = aam_Core_Request::post('users');

        if ($role->get_role($role_id)) {
            if ($users) {
                if (current_user_can('delete_users')) {
                    //delete users first
                    $users = new WP_User_Query(array(
                        'number' => '',
                        'blog_id' => aam_Core_Request::post('blog'),
                        'role' => aam_Core_Request::post('role')
                    ));
                    foreach ($users->get_results() as $user) {
                        //user can not delete himself
                        if ($user->data->ID !== get_current_user_id()) {
                            wp_delete_user($user->data->ID);
                        }
                    }
                    $role->remove_role($role_id);
                    $status = true;
                } else {
                    $status = false;
                }
            } else {
                $role->remove_role($role_id);
                $status = true;
            }
        } else {
            $status = false;
        }

        return json_encode(array('status' => ($status ? 'success' : 'failure')));
    }

}