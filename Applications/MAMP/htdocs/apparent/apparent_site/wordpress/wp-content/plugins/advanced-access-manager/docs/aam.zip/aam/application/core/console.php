<?php

class aam_Core_Console {

    public static function write($message) {
        file_put_contents(
                dirname(__FILE__) . '/console.log', $message . "\n", FILE_APPEND
        );
    }

}
