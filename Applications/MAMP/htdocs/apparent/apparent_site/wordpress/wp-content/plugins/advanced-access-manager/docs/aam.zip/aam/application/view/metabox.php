<?php

/**
 * ======================================================================
 * LICENSE: This file is subject to the terms and conditions defined in *
 * file 'license.txt', which is part of this source code package.       *
 * ======================================================================
 */
class aam_View_Metabox extends aam_View_Abstract {

    private $_post_type = null;
    private $_cache = array();

    public function run($post_type) {
        global $wp_meta_boxes;

        $this->_post_type = $post_type;
        $this->_cache = aam_Core_API::getBlogOption(
                        'aam_metabox_cache', array()
        );
        if (!isset($this->_cache[$post_type])) {
            $this->_cache[$post_type] = array();
        }

        if (aam_Core_Request::get('widget')) {
            $this->_cache['widgets'] = $this->getWidgetList();
        } else {
            if (is_array($wp_meta_boxes[$this->_post_type])) {
                foreach ($wp_meta_boxes[$this->_post_type] as $levels) {
                    if (is_array($levels)) {
                        foreach ($levels as $boxes) {
                            if (is_array($boxes)) {
                                foreach ($boxes as $data) {
                                    $this->_cache[$this->_post_type][$data['id']] = array(
                                        'id' => $data['id'],
                                        'title' => $this->removeHTML($data['title'])
                                    );
                                }
                            }
                        }
                    }
                }
            }
        }
        aam_Core_API::updateBlogOption('aam_metabox_cache', $this->_cache);
    }

    protected function getWidgetList() {
        global $wp_registered_widgets;
        $list = array();
        if (is_array($wp_registered_widgets)) {
            foreach ($wp_registered_widgets as $id => $data) {
                $list[$id] = array(
                    'title' => $this->removeHTML($data['name']),
                    'id' => $id
                );
            }
        }

        return $list;
    }

    public function initLink() {
        $link = filter_var(aam_Core_Request::post('link'), FILTER_VALIDATE_URL);
        if ($link) {
            $url = add_query_arg('aam_meta_init', 1, $link);
            aam_Core_API::cURL($url);
            $response = array('status' => 'success');
        } else {
            $response = array('status' => 'failure');
        }

        return json_encode($response);
    }

    public function retrieveList() {
        global $wp_post_types;

        if (aam_Core_Request::post('refresh') == 1) {
            aam_Core_API::deleteBlogOption('aam_metabox_cache');
            $type_list = array_keys($wp_post_types);
            array_unshift($type_list, 'widgets');
            array_unshift($type_list, 'dashboard');

            foreach ($type_list as $type) {
                switch ($type) {
                    case 'dashboard':
                        $url = add_query_arg('aam_meta_init', 1, admin_url('index.php'));
                        break;

                    case 'widgets':
                        $url = add_query_arg(array('aam_meta_init' => 1, 'widget' => 1), admin_url('index.php'));
                        break;

                    default:
                        $url = add_query_arg('aam_meta_init', 1, admin_url('post-new.php?post_type=' . $type));
                        break;
                }
                //grab metaboxes
                aam_Core_API::cURL($url);
            }
        }

        return $this->buildMetaboxList();
    }

    protected function buildMetaboxList() {
        global $wp_post_types;

        $cache = aam_Core_API::getBlogOption('aam_metabox_cache', array());
        if ($this->isAnonimus()) {
            $list = array(
                'widgets' => (isset($cache['widgets']) ? $cache['widgets'] : array())
            );
        } else {
            $list = $cache;
        }

        $content = '<div id="metabox_list">';
        foreach ($list as $group => $metaboxes) {
            $content .= '<div class="group">';
            switch ($group) {
                case 'dashboard':
                    $content .= '<h4>Dashboard Widgets</h4>';
                    break;

                case 'widgets':
                    $content .= '<h4>Frontend Widgets</h4>';
                    break;

                default:
                    $content .= '<h4>' . ($wp_post_types[$group]->labels->name) . '</h4>';
                    break;
            }
            $content .= '<div>';
            $content .= '<div class="metabox-group">';
            $i = 1;
            $metaboxControl = $this->getSubject()->getObject(aam_Control_Metabox::UID);
            $metaboxControl->init();
            foreach ($metaboxes as $metabox) {
                if ($i++ == 1) {
                    $content .= '<div class=metabox-row>';
                }
                if (strlen($metabox['title']) > 15) {
                    $title = substr($metabox['title'], 0, 12) . '...';
                } else {
                    $title = $metabox['title'];
                }
                $content .= '<div class="metabox-item">';
                $content .= '<label for="metabox_' . $group . '_' . $metabox['id'] . '" tooltip="' . js_escape($metabox['title']) . '">' . $title . '</label>';
                $checked = ($metaboxControl->has($group, $metabox['id']) ? 'checked="checked"' : '');
                $content .= '<input type="checkbox" id="metabox_' . $group . '_' . $metabox['id'] . '" name="aam[' . aam_Control_Metabox::UID . '][' . $group . '][' . $metabox['id'] . ']" ' . $checked . ' />';
                $content .= '<label for="metabox_' . $group . '_' . $metabox['id'] . '"><span></span></label>';
                $content .= '</div>';
                if ($i > 3) {
                    $content .= '</div>';
                    $i = 1;
                }
            }
            if ($i != 1) {
                $content .= '</div>';
            }
            $content .= '</div></div></div>';
        }
        $content .= '</div>';

        return json_encode(array('content' => $content));
    }

    public function removeHTML($text) {
        return preg_replace(array("'<span[^>]*?>.*?</span[^>]*?>'si"), '', $text);
    }

    public function content() {
        return $this->loadTemplate(dirname(__FILE__) . '/tmpl/metabox.phtml');
    }

}
