<?php

/**
 * ======================================================================
 * LICENSE: This file is subject to the terms and conditions defined in *
 * file 'license.txt', which is part of this source code package.       *
 * ======================================================================
 */

/**
 * Abstract Subject class
 *
 * @package AAM
 * @author Vasyl Martyniuk <support@wpaam.com>
 * @copyright Copyright C 2013 Vasyl Martyniuk
 */
abstract class aam_Control_Subject {

    /**
     * Subject ID
     * 
     * Whether it is User ID or Role ID
     * 
     * @var string|int
     * 
     * @access private 
     */
    private $_id;

    /**
     * Current Blog ID
     * 
     * @var int
     * 
     * @access private 
     */
    private $_blog_id;

    /**
     * Subject itself
     * 
     * It can be WP_User or WP_Role, based on what class has been used
     * 
     * @var WP_Role|WP_User
     * 
     * @access private 
     */
    private $_subject;

    /**
     * List of Objects to be access controled for current subject
     * 
     * All access control objects like Admin Menu, Metaboxes, Posts etc
     * 
     * @var array
     * 
     * @access private 
     */
    private $_objects = array();

    /**
     * Constructor
     * 
     * @param string|int $id
     * @param int        $blog_id
     * 
     * @return void
     * 
     * @access public
     */
    public function __construct($id, $blog_id) {
        //set subject & blog ID
        $this->setId($id);
        $this->setBlogId($blog_id);
        //retrieve and set subject itself
        $this->setSubject($this->retrieveSubject());
        //prepare and set subject's access objects
        $this->setObjects($this->retrieveObjects());
    }

    /**
     * Trigger Subject native methods
     * 
     * @param string $name
     * @param array  $arguments
     * 
     * @return mixed
     * 
     * @access public
     */
    public function __call($name, $arguments) {
        $subject = $this->getSubject();
        //make sure that method is callable
        if (method_exists($subject, $name)) {
            $response = call_user_func_array(array($subject, $name), $arguments);
        } else {
            aam_Core_Console::write(
                    "Method {$name} does not exist in " . get_class($subject)
            );
            $response = null;
        }

        return $response;
    }

    /**
     * Get Subject's native properties
     * 
     * @param string $name
     * 
     * @return mixed
     * 
     * @access public
     */
    public function __get($name) {
        $subject = $this->getSubject();
        //make sure that method is callable
        if (property_exists($subject, $name)) {
            $response = $subject->$name;
        } else {
            aam_Core_Console::write(
                    "Property {$name} does not exist in " . get_class($subject)
            );
            $response = null;
        }

        return $response;
    }

    /**
     * Set Subject ID
     * 
     * @param string|int
     * 
     * @return void
     * 
     * @access public
     */
    public function setId($id) {
        $this->_id = $id;
    }

    /**
     * Get Subject ID
     * 
     * @return string|int
     * 
     * @access public
     */
    public function getId() {
        return $this->_id;
    }

    /**
     * Set Blog ID
     * 
     * @param int $blog_id
     * 
     * @access public
     */
    public function setBlogId($blog_id) {
        $this->_blog_id = $blog_id;
    }

    /**
     * Get Blog ID
     * 
     * @return int
     * 
     * @access public
     */
    public function getBlogId() {
        return $this->_blog_id;
    }

    /**
     * Get Subject
     * 
     * @return WP_Role|WP_User
     * 
     * @access public
     */
    public function getSubject() {
        return $this->_subject;
    }

    /**
     * Set Subject
     * 
     * @param WP_Role|WP_User $subject
     * 
     * @return void
     * 
     * @access public
     */
    public function setSubject($subject) {
        $this->_subject = $subject;
    }

    /**
     * Get Access Objects
     * 
     * @return array
     * 
     * @access public
     */
    public function getObjects() {
        return $this->_objects;
    }

    /**
     * Get Individual Access Object
     * 
     * @param string $object
     * @param mixed  $object_id
     * 
     * @return aam_Control_Object
     * 
     * @access public
     */
    public function getObject($object, $object_id = '') {
        if (isset($this->_objects[$object])) {
            $this->_objects[$object]->init($object_id);
            $response = $this->_objects[$object];
        } else {
            aam_Core_Console::write(
                    "Access object {$object} does not exist"
            );
            $response = null;
        }

        return $response;
    }

    /**
     * Set Individual Access Object
     * 
     * @param aam_Control_Object $object
     * @param string             $uid
     * 
     * @return void
     * 
     * @access public
     */
    public function setObject(aam_Control_Object $object, $uid) {
        $this->_objects[$uid] = $object;
    }

    /**
     * Set Access Objects
     * 
     * @param array $objects
     * 
     * @return void
     * 
     * @access public
     */
    public function setObjects(array $objects) {
        $this->_objects = $objects;
    }

    /**
     * Get Subject Type
     * 
     * @return string
     * 
     * @access public
     */
    public function getType() {
        return get_class($this->getSubject());
    }

    /**
     * Check if Subject has capability
     * 
     * Keep compatible with WordPress core
     * 
     * @param string $capability
     * 
     * @return boolean
     * 
     * @access public
     */
    abstract public function hasCapability($capability);

    /**
     * Update Capability
     * 
     * Whether add or remove the capability from the subject
     * 
     * @param string  $capability
     * @param boolean $grant
     * 
     * @return boolean
     * 
     * @access public
     */
    abstract public function updateCapability($capability, $grant);

    /**
     * Retrieve list of subject's capabilities
     * 
     * @return array
     * 
     * @access public
     */
    abstract public function getCapabilities();

    /**
     * Save Access Parameters
     * 
     * @param array $params
     * 
     * @return boolean
     * 
     * @access public
     */
    abstract public function save(array $params);

    /**
     * Retrieve subject based on used class
     * 
     * @return void
     * 
     * @access protected
     */
    abstract protected function retrieveSubject();

    /**
     * Retrieve subject's access objects
     * 
     * @return array
     * 
     * @access protected
     */
    abstract protected function retrieveObjects();
}
