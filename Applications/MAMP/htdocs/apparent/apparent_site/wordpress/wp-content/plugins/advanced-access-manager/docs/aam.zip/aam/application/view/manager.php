<?php
/**
 * ======================================================================
 * LICENSE: This file is subject to the terms and conditions defined in *
 * file 'license.txt', which is part of this source code package.       *
 * ======================================================================
 */

/**
 * GUI Manager
 *
 * @package AAM
 * @subpackage Models
 * @author Vasyl Martyniuk <support@wpaam.com>
 * @copyrights Copyright © 2013 Vasyl Martyniuk
 * @license GNU General Public License {@link http://www.gnu.org/licenses/}
 */
class aam_View_Manager extends aam_View_Abstract {

    private $_cmanager = array();
    private $_features = array();

    /**
     * Constructor
     *
     * The filter "aam_cpanel" can be used to control the Control Panel items.
     *
     * @return void
     *
     * @access public
     */
    public function __construct() {
        parent::__construct();

        $this->setCManager(
                apply_filters('aam_levels_ui', $this->getDefaultLevels())
        );
        $this->setFeatures(
                apply_filters('aam_features_ui', $this->getDefaultFeatures())
        );
    }

    protected function getDefaultLevels() {
        return array(
            'roles' => array(
                'position' => 5,
                'segment' => 'role',
                'label' => __('Roles', 'aam'),
                'title' => __('Role Manager', 'aam'),
                'class' => 'manager-item manager-item-role',
                'id' => 'aam_role',
                'content' => array(new aam_View_Role(), 'content')
            ),
            'users' => array(
                'position' => 10,
                'segment' => 'user',
                'label' => __('Users', 'aam'),
                'title' => __('User Manager', 'aam'),
                'class' => 'manager-item manager-item-user',
                'id' => 'aam_user',
                'content' => array(new aam_View_User(), 'content')
            ),
            'visitor' => array(
                'position' => 15,
                'segment' => 'visitor',
                'label' => __('Visitor', 'aam'),
                'title' => __('Visitor Manager', 'aam'),
                'class' => 'manager-item manager-item-visitor',
                'id' => 'aam_visitor',
                'content' => array(new aam_View_Visitor(), 'content')
            )
        );
    }

    protected function getDefaultFeatures() {
        return array(
            'admin_menu' => array(
                'id' => 'admin_menu',
                'position' => 5,
                'title' => __('Admin Menu', 'aam'),
                'anonimus' => false,
                'content' => array(new aam_View_Menu(), 'content'),
                'help' => __('Control Access to Admin Menu for selected Role or User.', 'aam')
            ),
            'metabox' => array(
                'id' => 'metabox',
                'position' => 10,
                'title' => __('Metabox & Widget', 'aam'),
                'anonimus' => true,
                'content' => array(new aam_View_Metabox(), 'content'),
                'help' => __('Control Access to Metaboxes and Widgets', 'aam')
            ),
            'capability' => array(
                'id' => 'capability',
                'position' => 15,
                'title' => __('Capability', 'aam'),
                'anonimus' => false,
                'content' => array(new aam_View_Capability(), 'content'),
                'help' => __('Manage capabilities', 'aam')
            ),
            'post_access' => array(
                'id' => 'post_access',
                'position' => 20,
                'title' => __('Posts & Categories', 'aam'),
                'anonimus' => true,
                'content' => array(new aam_View_Post(), 'content'),
                'help' => __('Manage access to Posts and Categories', 'aam')
            ),
            'event_manager' => array(
                'id' => 'event_manager',
                'position' => 25,
                'title' => __('Event Manager', 'aam'),
                'anonimus' => false,
                'content' => array(new aam_View_Event(), 'content'),
                'help' => __('Manage WordPress Events', 'aam')
            ),
            'config_press' => array(
                'id' => 'configpress',
                'position' => 30,
                'title' => __('ConfigPress', 'aam'),
                'anonimus' => true,
                'content' => array(new aam_View_ConfigPress(), 'content'),
                'help' => __('Advanced Access Manager Configurations', 'aam')
            )
        );
    }

    /**
     * Set Control Panel items
     *
     * @param array $cpanel
     *
     * @return void
     *
     * @access public
     */
    public function setCManager(array $cmanager) {
        $final = array();
        foreach ($cmanager as $item) {
            if (!isset($final[$item['position']])) {
                $final[$item['position']] = $item;
            } else {
                aam_Extension_Console::log(
                        "Control Manager position {$item['position']} reserved already"
                );
            }
        }
        ksort($final);

        $this->_cmanager = $final;
    }

    /**
     * Get Control Panel items
     *
     * @return array
     *
     * @access public
     */
    public function getCManager() {
        return $this->_cmanager;
    }

    public function setFeatures($list) {
        $final = array();
        foreach ($list as $item) {
            if (!isset($final[$item['position']])) {
                $final[$item['position']] = $item;
            } else {
                aam_Extension_Console::log(
                        "Feature position {$item['position']} reserved already"
                );
            }
        }
        ksort($final);

        $this->_features = $final;
    }

    public function getFeatures() {
        return $this->_features;
    }

    /**
     * Run the Manager
     *
     * @return string
     *
     * @access public
     */
    public function run() {
        return $this->loadTemplate(dirname(__FILE__) . '/tmpl/manager.phtml');
    }

    public function retrieveFeatures() {
        ?>
        <div class="aam-help">
            <?php
            foreach ($this->getFeatures() as $feature) {
                if (!$this->isAnonimus() || $feature['anonimus']) {
                    echo '<span id="feature_help_' . $feature['id'] . '">', $feature['help'], '</span>';
                }
            }
            ?>
        </div>
        <div class="feature-list">
            <?php
            foreach ($this->getFeatures() as $feature) {
                if (!$this->isAnonimus() || $feature['anonimus']) {
                    echo '<div class="feature-item" feature="' . $feature['id'] . '">';
                    echo '<span>' . $feature['title'] . '</span></div>';
                }
            }
            ?>
        </div>
        <div class="feature-content">
            <?php
            foreach ($this->getFeatures() as $feature) {
                if (!$this->isAnonimus() || $feature['anonimus']) {
                    echo call_user_func($feature['content']);
                }
            }
            ?>
        </div>
        <br class="clear" />
        <?php
    }

    public function save() {
        $this->getSubject()->save(aam_Core_Request::post('aam'));
        return json_encode(array('status' => 'success'));
    }

}
