<?php

class aam_Control_ConfigPress extends aam_Control_Object {

    const UID = 'configpress';

    private $_option = '';

    public function save(array $params) {
        $config = (isset($params[self::UID]) ? $params[self::UID] : '');

        if (trim($config)) {
            aam_Core_API::updateBlogOption('aam_' . self::UID, $config);
        }
    }

    public function init($object_id = '') {
        if ($this->getObjectId() !== $object_id) {
            $this->setOption(aam_Core_API::getBlogOption('aam_' . self::UID, ''));
        }
    }

    public function setOption(array $option) {
        $this->_option = $option;
    }

    public function getOption() {
        return $this->_option;
    }

}
