<?php

/**
 * ======================================================================
 * LICENSE: This file is subject to the terms and conditions defined in *
 * file 'license.txt', which is part of this source code package.       *
 * ======================================================================
 */
class aam_View_Event extends aam_View_Abstract {

    public function retrieveEventList() {
        $response = array('aaData' => array());
        foreach ($this->getSubject()->getObject(aam_Control_Event::UID)->getOption() as $event) {
            $response['aaData'][] = array(
                $event['event'],
                $event['event_specifier'],
                $event['post_type'],
                $event['action'],
                $event['action_specifier'],
                ''
            );
        }

        return json_encode($response);
    }

    public function getPostStatuses() {
        global $wp_post_statuses;

        return $wp_post_statuses;
    }

    public function getPostTypes() {
        global $wp_post_types;

        return $wp_post_types;
    }

    public function content() {
        return $this->loadTemplate(dirname(__FILE__) . '/tmpl/event.phtml');
    }

}
