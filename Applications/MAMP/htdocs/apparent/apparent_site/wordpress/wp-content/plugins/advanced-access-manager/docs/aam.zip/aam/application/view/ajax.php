<?php

/**
 * ======================================================================
 * LICENSE: This file is subject to the terms and conditions defined in *
 * file 'license.txt', which is part of this source code package.       *
 * ======================================================================
 */
class aam_View_Ajax {

    public function run() {
        switch (aam_Core_Request::request('sub_action')) {
            case 'role_list':
                $response = $this->retrieveRoleList();
                break;

            case 'user_list':
                $response = $this->retrieveUserList();
                break;

            case 'add_role':
                $response = $this->addRole();
                break;

            case 'edit_role':
                $response = $this->editRole();
                break;

            case 'delete_role':
                $response = $this->deleteRole();
                break;

            case 'add_user':
            case 'update_user':
                $response = $this->manageUser();
                break;

            case 'block_user':
                $response = $this->blockUser();
                break;

            case 'get_user':
                $response = $this->getUser();
                break;

            case 'delete_user':
                $response = $this->deleteUser();
                break;

            case 'load_metaboxes':
                $response = $this->loadMetaboxes();
                break;

            case 'init_link':
                $response = $this->initLink();
                break;

            case 'load_capabilities':
                $response = $this->loadCapabilities();
                break;

            case 'role_capabilities':
                $response = $this->getRoleCapabilities();
                break;

            case 'add_capability':
                $response = $this->addCapability();
                break;

            case 'delete_capability':
                $response = $this->deleteCapability();
                break;

            case 'post_type_list':
                $response = $this->getPostTypeList();
                break;

            case 'post_list':
                $response = $this->getPostList();
                break;

            case 'post_tree':
                $response = $this->getPostTree();
                break;

            case 'post_breadcrumb':
                $response = $this->generatePostBreadcrumb();
                break;

            case 'save_access':
                $response = $this->saveAccess();
                break;

            case 'get_access':
                $response = $this->getAccess();
                break;

            case 'clear_access':
                $response = $this->clearAccess();
                break;

            case 'event_list':
                $response = $this->getEventList();
                break;

            case 'save':
                $response = $this->save();
                break;

            default:
                $response = -1;
                break;
        }

        return $response;
    }

    protected function retrieveRoleList() {
        $model = new aam_View_Role;

        return $model->retrieveList();
    }

    protected function retrieveUserList() {
        $model = new aam_View_User;

        return $model->retrieveList();
    }

    protected function addRole() {
        $model = new aam_View_Role;

        return $model->add();
    }

    protected function editRole() {
        $model = new aam_View_Role;

        return $model->edit();
    }

    protected function deleteRole() {
        $model = new aam_View_Role;

        return $model->delete();
    }

    protected function manageUser() {
        $model = new aam_View_User;

        return $model->edit();
    }

    protected function getUser() {
        $model = new aam_View_User;

        return $model->read();
    }

    protected function blockUser() {
        $model = new aam_View_User;

        return $model->block();
    }

    protected function deleteUser() {
        $model = new aam_View_User;

        return $model->delete();
    }

    protected function loadMetaboxes() {
        $model = new aam_View_Metabox;

        return $model->retrieveList();
    }

    protected function initLink() {
        $model = new aam_View_Metabox;

        return $model->initLink();
    }

    protected function loadCapabilities() {
        $model = new aam_View_Capability;

        return $model->retrieveList();
    }

    protected function getRoleCapabilities() {
        $model = new aam_View_Capability;

        return $model->retrieveRoleCapabilities();
    }

    protected function addCapability() {
        $model = new aam_View_Capability;

        return $model->addCapability();
    }

    protected function deleteCapability() {
        $model = new aam_View_Capability;

        return $model->deleteCapability();
    }

    protected function getPostTypeList() {
        $model = new aam_View_Post;

        return $model->retrievePostTypeList();
    }

    protected function getPostList() {
        $model = new aam_View_Post;

        return $model->retrievePostList();
    }

    protected function getPostTree() {
        $model = new aam_View_Post;

        return $model->getPostTree();
    }

    protected function saveAccess() {
        $model = new aam_View_Post();

        return $model->saveAccess();
    }

    protected function getAccess() {
        $model = new aam_View_Post();

        return $model->getAccess();
    }
    
    protected function clearAccess() {
        $model = new aam_View_Post();

        return $model->clearAccess();
    }

    protected function generatePostBreadcrumb() {
        $model = new aam_View_Post;

        return $model->getPostBreadcrumb();
    }

    protected function getEventList() {
        $model = new aam_View_Event;

        return $model->retrieveEventList();
    }

    protected function save() {
        $model = new aam_View_Manager;

        return $model->save();
    }

}
